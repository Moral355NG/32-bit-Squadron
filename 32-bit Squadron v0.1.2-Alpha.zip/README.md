# 32bit Squadron
v0.1.0-Alpha
## About this project
A game where you dodge enemy aircraft over a randomly generated landscape.
## Gallery
![Game Screenshot](https://github.com/user-attachments/assets/c15d9bb6-0ffc-4c80-b881-273cdf50c57d)
## Credits
### Programmer
Moral355NG
### Artist
Joquicx
### Musician
Montecarlo968
### Narrator
Flameblade
